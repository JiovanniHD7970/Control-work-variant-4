#include <stdio.h>

// Функция для вычисления абсолютного значения числа без использования abs
int MyAbs(int num) {
    if (num < 0) {
        return -num;  // Если число отрицательное, делаем его положительным
    }
    return num;  // Если число положительное или ноль, возвращаем его как есть
}

// Функция для вычисления суммы цифр числа
int SumDigits(int num) {
    int sum = 0;
    while (num > 0) {
        sum += num % 10;  // Получаем последнюю цифру числа и добавляем к сумме
        num /= 10;         // Убираем последнюю цифру
    }
    return sum;
}

// Функция для проверки, является ли число пятиугольным
// Пятиугольные числа: Pn = n * (3n - 1) / 2, где n = 1, 2, 3, ...
int IsFive(int sum) {
    for (int n = 1; ; n++) {
        int pentagonal = n * (3 * n - 1) / 2;
        if (pentagonal == sum) {
            return 1;  // Число пятиугольное
        }
        if (pentagonal > sum) {
            return 0;  // Число не является пятиугольным
        }
    }
}

// Функция для проверки, равна ли разность между соседними цифрами числу k
int IsDifference(int num, int k) {
    int prev_digit = num % 10;
    num /= 10;
    while (num > 0) {
        int curr_digit = num % 10;
        if (MyAbs(curr_digit - prev_digit) != k) {  // Используем MyAbs вместо abs
            return 0;  // Разность между соседними цифрами не равна k
        }
        prev_digit = curr_digit;
        num /= 10;
    }
    return 1;  // Разность между соседними цифрами равна k
}

// Основная функция для проверки чисел
int CheckNumber(int num, int k) {
    int sum = SumDigits(num);  // Сумма цифр числа
    if (IsFive(sum) && IsDifference(num, k)) {
        return 1;  // Число удовлетворяет условиям
    }
    return 0;  // Число не удовлетворяет условиям
}

// Функция для печати ряда пятиугольных чисел
void PrintFive(int limit) {
    int n = 1;
    while (1) {
        int pentagonal = n * (3 * n - 1) / 2;
        if (pentagonal > limit) break;
        printf("%d ", pentagonal);
        n++;
    }
    printf("\n");
}

// Функция для печати чисел в заданном диапазоне, обладающих заданными свойствами
void PrintNumbers(int n, int m, int k) {
    for (int num = n; num <= m; num++) {
        if (CheckNumber(num, k)) {
            printf("%d ", num);
        }
    }
    printf("\n");
}

// Функция для ввода чисел с консоли и подсчёта чисел, обладающих заданными свойствами
void InputNumbers(int k) {
    int num, count = 0;
    while (1) {
        printf("Vvedite chislo (0 0 dlya togo, chtoby zavershit'): ");
        scanf("%d", &num);
        if (num == 0) {
            int second_num;
            scanf("%d", &second_num);
            if (second_num == 0) {
                break;  // Завершаем программу, если введены два нуля
            }
        }
        if (CheckNumber(num, k)) {
            count++;
        }
    }
    printf("Obshcheye kollichestvo: %d\n", count);
}

// Функция для ввода данных и печати результатов
void EntryAndPrint() {
    int choice, n, m, k;
    printf("Vvedite:\n1 - Dlya vyvoda nuzhnih chisel v diapazone,\n2 - Dlya vvedeniya svoih chisel v konsoli:\n");
    scanf("%d", &choice);
    
    if (choice == 1) {
        printf("Vvedite diapazon [n, m]:\n");
        scanf("%d %d", &n, &m);
        printf("Vvedite k: ");
        scanf("%d", &k);
        printf("Chisla v diapazone [%d, %d], kotorye obladayut svoistvami:\n", n, m);
        PrintNumbers(n, m, k);
    } else if (choice == 2) {
        printf("Vvedite k: ");
        scanf("%d", &k);
        InputNumbers(k);
    }
}

int main() {
    int continue_program = 1;
    while (continue_program) {
        EntryAndPrint();
        // Запрос на продолжение
        printf("Proverit' drugie chisla? (1 - Da, 0 - Viyti): ");
        scanf("%d", &continue_program);
    }
    printf("Programma zavershena.\n");
    
return 0;
}
