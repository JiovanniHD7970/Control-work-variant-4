#include <stdio.h>

// Функция проверки попадания точки внутрь первой параболы
// Уравнение первой параболы: y = -x^2 + 8x
int IsParabola1(double x, double y) {
    // Вычисляем значение функции параболы в точке x
    double parabola1_y = -x * x + 8 * x;
    // Проверяем, находится ли точка ниже параболы
    return y <= parabola1_y;
}

// Функция проверки попадания точки внутрь второй параболы
// Уравнение второй параболы: y = -x^2 + 4x
int IsParabola2(double x, double y) {
    // Вычисляем значение функции параболы в точке x
    double parabola2_y = -x * x + 4 * x;
    // Проверяем, находится ли точка ниже параболы
    return y <= parabola2_y;
}

// Функция проверки попадания точки под прямую
// Уравнение прямой: y = -x + 8
int UnderLine(double x, double y) {
    // Вычисляем значение функции прямой в точке x
    double line_y = -x + 8;
    // Проверяем, находится ли точка под прямой
    return y <= line_y;
}

// Основная функция для проверки попадания точки в область
int CheckArea(double x, double y) {
    // Если точка под первой параболой, но выше второй
    if (IsParabola1(x, y) && !IsParabola2(x, y)) {
        return 1; // Область 1
    }
    // Если точка между второй параболой и прямой
    if (IsParabola2(x, y) && UnderLine(x, y)) {
        return 2; // Область 2
    }
    // Если точка под первой параболой и прямой, но не под второй параболой
    if (IsParabola1(x, y) && UnderLine(x, y) && !IsParabola2(x, y)) {
        return 3; // Область 3
    }
    // Если точка под второй параболой, но не под прямой
    if (IsParabola2(x, y) && !UnderLine(x, y)) {
        return 4; // Область 4
    }
    // Если точка выше прямой и парабол
    return 0; // Точка вне областей
}

int main() {
    double x, y;
    int continue_program = 1;
    
    while (continue_program) {
        // Запрос на ввод X
        printf("Vvedite X: ");
        scanf("%lf", &x);
        
        // Запрос на ввод Y
        printf("Vvedite Y: ");
        scanf("%lf", &y);
        
        // Проверка области
        int area = CheckArea(x, y);
        
        // Вывод номера области
        if (area == 0) {
            printf("Tochka ne popadaet ni v odnu oblast'.\n");
        } else {
            printf("Tochka nahodits'a v oblasti %d.\n", area);
        }
        
        // Запрос на продолжение
        printf("Hotite proverit' druguyu tochku? (1 - Da, 0 - Viyti): ");
        scanf("%d", &continue_program);
    }
    
    printf("Programma zavershena.\n");
    return 0;
}