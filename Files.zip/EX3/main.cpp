#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define errOK 0
#define errFileName 1
#define errFileNotFound 2
#define errCanNotOpenFile 3
#define errArraySize 4
#define errNotMemory 5
#define errArrayElement 6
#define errAbsentElements 7
#define errFileExists 8
#define errFileIsReadOnly 9
#define errCanNotSaveValue 10

// Прототипы функций
typedef int errCode;

errCode LoadArray(double** pArray, int* Size, char* Name);
errCode SaveArray(double* pArray, int Size, char* Name, bool rw);
void ShowArray(double* pArray, int Size);
errCode InputArray(double** pArray, int* Size);
double CalcCriteria(double* pArray, int Left, int Right);
void Search(double* Arr, int Size, bool Opt, int* Begin, int* End);
bool CheckFileName(char* name);
errCode TestArray(double** pArray, int* Size);

int main() {
    double* array = NULL;
    int size = 0;
    int begin = 0, end = 0;
    bool opt = true;
    int choice;
    char filename[256];

    while (1) {
        printf("\n----- MENYU -----\n");
        printf("1. Sozdat testoviy massiv\n");
        printf("2. Vvod massiva s konsoli\n");
        printf("3. Pokazat massiv\n");
        printf("4. Sohranit massiv v fayl\n");
        printf("5. Zagrusit massiv iz fayla\n");
        printf("6. Poisk maksimal'noy/ minimal'noy sumy\n");
        printf("7. Vykhod\n");
        printf("Vyberite komandu: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: {
                // Testovyy massiv
                if (TestArray(&array, &size) != errOK) {
                    printf("Oshibka pri sozdanii testovogo massiva!\n");
                } else {
                    printf("Testovyy massiv sozdan uspekhom!\n");
                }
                break;
            }
            case 2: {
                // Vvod massiva s konsoli
                if (InputArray(&array, &size) != errOK) {
                    printf("Oshibka pri vvedenii massiva!\n");
                } else {
                    printf("Massiv vveden uspekhom!\n");
                }
                break;
            }
            case 3: {
                // Pokazat massiv
                if (array == NULL) {
                    printf("Massiv ne sozdann!\n");
                } else {
                    ShowArray(array, size);
                }
                break;
            }
            case 4: {
                // Sohranit massiv v fayl
                printf("Vvedite imya fayla dlya sohraneniya: ");
                scanf("%s", filename);
                bool overwrite;
                printf("Perezapisat' fayl? (1 - da, 0 - net): ");
                scanf("%d", &overwrite);
                if (SaveArray(array, size, filename, overwrite) != errOK) {
                    printf("Oshibka pri sohranenii massiva v fayl!\n");
                } else {
                    printf("Massiv uspesno sohranеn!\n");
                }
                break;
            }
            case 5: {
                // Zagrusit massiv iz fayla
                printf("Vvedite imya fayla dlya zagruzki: ");
                scanf("%s", filename);
                if (LoadArray(&array, &size, filename) != errOK) {
                    printf("Oshibka pri zagruzke massiva iz fayla!\n");
                } else {
                    printf("Massiv uspesno zagruzhen!\n");
                }
                break;
            }
            case 6: {
                // Poisk maksimal'noy/minimal'noy summy
                if (array == NULL) {
                    printf("Massiv ne sozdann!\n");
                } else {
                    printf("Vvedite kriteriy poiska (1 - max, 0 - min): ");
                    scanf("%d", &opt);
                    Search(array, size, opt, &begin, &end);
                    printf("Naydennaya posledovatel'nost':\n");
                    printf("Nachalo: %d, Konets: %d\n", begin, end);
                }
                break;
            }
            case 7: {
                // Vykhod
                free(array);
                printf("Vykhod iz programmy.\n");
                return 0;
            }
            default:
                printf("Nekorrektnyy vvod. Povtorite\n");
        }
    }
    return 0;
}

// Funktcii

// Zagruska massiva iz fayla
errCode LoadArray(double** pArray, int* Size, char* Name) {
    FILE* file = fopen(Name, "r");
    if (!file) {
        return errCanNotOpenFile;
    }

    if (fscanf(file, "%d", Size) != 1) {
        fclose(file);
        return errArraySize;
    }

    *pArray = (double*)malloc(*Size * sizeof(double));
    if (*pArray == NULL) {
        fclose(file);
        return errNotMemory;
    }

    for (int i = 0; i < *Size; i++) {
        if (fscanf(file, "%lf", &(*pArray)[i]) != 1) {
            free(*pArray);
            fclose(file);
            return errArrayElement;
        }
    }

    fclose(file);
    return errOK;
}

// Sohranenie massiva v fayl
errCode SaveArray(double* pArray, int Size, char* Name, bool rw) {
    FILE* file = fopen(Name, "r+");
    if (file) {
        if (rw) {
            printf("Fayl sushchestvuet. Zamenit'? (1 - da, 0 - net): ");
            char c;
            scanf(" %c", &c);
            if (c != '1') {
                fclose(file);
                return errFileExists;
            }
        } else {
            fclose(file);
            return errFileIsReadOnly;
        }
    } else {
        file = fopen(Name, "w");
        if (!file) {
            return errCanNotOpenFile;
        }
    }

    fprintf(file, "%d\n", Size);
    for (int i = 0; i < Size; i++) {
        fprintf(file, "%lf\n", pArray[i]);
    }

    fclose(file);
    return errOK;
}

// Pokazat massiv
void ShowArray(double* pArray, int Size) {
    printf("Massiv: ");
    for (int i = 0; i < Size; i++) {
        printf("%lf ", pArray[i]);
    }
    printf("\n");
}

// Vvod massiva s konsoli
errCode InputArray(double** pArray, int* Size) {
    printf("Vvedite razmer massiva: ");
    scanf("%d", Size);

    *pArray = (double*)malloc(*Size * sizeof(double));
    if (*pArray == NULL) {
        return errNotMemory;
    }

    for (int i = 0; i < *Size; i++) {
        printf("Vvedite element %d: ", i);
        scanf("%lf", &(*pArray)[i]);
    }

    return errOK;
}

// Raschet srednego arifmeticheskogo
double CalcCriteria(double* pArray, int Left, int Right) {
    double sum = 0;
    for (int i = Left; i <= Right; i++) {
        sum += pArray[i];
    }
    return sum / (Right - Left + 1);
}

// Poisk maksimal'noy/minimal'noy sumy
void Search(double* Arr, int Size, bool Opt, int* Begin, int* End) {
    double bestValue = Opt ? -1e10 : 1e10;
    for (int i = 0; i < Size - 1; i++) {
        for (int j = i + 1; j < Size; j++) {
            double current = CalcCriteria(Arr, i, j);
            if ((Opt && current > bestValue) || (!Opt && current < bestValue)) {
                bestValue = current;
                *Begin = i;
                *End = j;
            }
        }
    }
}

// Proverka imeni fayla
bool CheckFileName(char* name) {
    return (strlen(name) > 0);
}

// Testovyy massiv
errCode TestArray(double** pArray, int* Size) {
    *Size = 5;
    *pArray = (double*)malloc(*Size * sizeof(double));
    if (*pArray == NULL) {
        return errNotMemory;
    }

    (*pArray)[0] = 1.0;
    (*pArray)[1] = 2.0;
    (*pArray)[2] = -1.0;
    (*pArray)[3] = 3.0;
    (*pArray)[4] = -4.0;

    return errOK;
}